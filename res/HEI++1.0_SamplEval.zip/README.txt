=================================================================================
                              Hei++ 1.0 and SamplEval
                             http://generationary.org/

                  Michele Bevilacqua, Marco Maru and Roberto Navigli

                                  Sapienza NLP
                           Sapienza Università di Roma
                             http://nlp.uniroma1.it
=================================================================================


Hei++ is a dataset which associates human-made definitions with 713 
adjective-noun phrases, hence enabling the assessment of definition generation 
quality on free phrases not commonly found in traditional dictionaries.

Hei++ is licensed under the CC BY-NC-SA 4.0 License.

SamplEval is a sample of 1,000 random instances made up of 200 items for each of
the five WSD datasets included in the evaluation framework of Raganato et al. 
(2017),* with at most one total instance per distinct word sense.

* Alessandro Raganato, Jose Camacho-Collados and Roberto Navigli, 
"Word Sense Disambiguation: A Unified Evaluation Framework and Empirical 
Comparison", Proceedings of EACL 2017, Valencia, Spain.


=================================================================================
PACKAGE CONTENTS
=================================================================================


* README.txt (this file);
* LICENSE.txt (terms and conditions of the CC BY-NC-SA 4.0 License);
* HEI++_1.0.txt (all the 713 phrases and definitions available in Hei++);
* SAMPLEVAL.txt (the list of 1,000 identifiers for the instances in SamplEval). 


=================================================================================
FORMAT (HEI++)
=================================================================================


All the entries in HEI++_1.0.txt are provided in plain text format.
Each entry is a tab-separated line terminated by a line feed character.
Each entry shows, in the following order:
	
1. adjective-noun phrase (lower-cased, with underscore-separated words);
2. human-made definition for the corresponding adjective-noun phrase.

For example:

final_answer	An answer that admits no further replies.
good-natured_play	A cheerful way of playing (e.g. of puppies).
incorporeal_spirit	A supernatural spirit having no material form.


=================================================================================
FORMAT (SAMPLEVAL)
=================================================================================


All the entries in SAMPLEVAL.txt are provided in plain text format.
Each entry is terminated by a line feed character and shows:
	
1. instance identifier, as taken from the "ALL" concatenated dataset in the 
evaluation framework of Raganato et al. (2017).

For example:

semeval2007.d000.s012.t003
semeval2015.d001.s023.t010
senseval3.d000.s023.t005


=================================================================================
REFERENCE PAPER
=================================================================================


When using these resources, please refer to the following paper:

	Michele Bevilacqua, Marco Maru and Roberto Navigli

	"Generationary or: 'How We Went beyond Word Sense Inventories and Learned
        to Gloss'"

	In Proceedings of the 2020 Conference on Empirical Methods in Natural 
	Language Processing (EMNLP), Online, November 16-20, 2020, 
        pages 7207-7221.


=================================================================================
ACKNOWLEDGEMENTS
=================================================================================


The authors gratefully acknowledge the support of the ERC Consolidator Grant 
MOUSSE No. 726487 under the European Union’s Horizon 2020 research and innovation 
programme (http://mousse-project.org/).

The authors also wish to thank Jim McManus for revising the definitions in Hei++.


=================================================================================
CONTACTS
=================================================================================


If you have any enquiries, please contact:

Michele Bevilacqua - Sapienza Università di Roma
(bevilacqua [at] di [dot] uniroma1 [dot] it)

Marco Maru - Sapienza Università di Roma
(marco [dot] maru [at] uniroma1 [dot] it)

Roberto Navigli - Sapienza Università di Roma
(navigli [at] di [dot] uniroma1 [dot] it)